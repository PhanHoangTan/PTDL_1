'''
Viết hàm tính giá trị bình phương của một số
Sau đó, gọi hàm
'''
# Khai báo hàm
def calSquare(n):
    result = n*n
    return result
# Gọi hàm
x = calSquare(10)
print('Bình phương của 10 là: ',x)