# Kiểu dữ liệu chuỗi
a = "Hello" # Python hiểu a là kiểu chuỗi
print(a)
b = 'World' # Python hiểu b là kiểu chuỗi
print(b)
# Sử dụng \n để xuống dòng
print("Python programming \n for Data Analysis")
# Sử dụng f để hiện thị giá trị
print(f'Giá trị biến a là: {a}')