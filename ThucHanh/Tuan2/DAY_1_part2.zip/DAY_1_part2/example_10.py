# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 14:08:35 2022

@author: Student
"""

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-5,5,1000)
y = x**2

plt.plot(x,y)
plt.show()


